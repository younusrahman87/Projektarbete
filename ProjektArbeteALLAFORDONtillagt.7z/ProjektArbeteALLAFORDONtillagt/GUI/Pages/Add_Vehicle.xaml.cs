﻿using Logic;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Logic.Vehicle;
using Logic.Services;
using System.Buffers;
using System.Linq;
using System.IO;

namespace GUI.Pages
{
    /// <summary>
    /// Interaction logic for Add_vehicle.xaml
    /// </summary>
    public partial class Add_vehicle : Page
    {

        private CheckPost _check;

        private  bool found;
        private string vehicle_typ;


        public Add_vehicle()
        {                        
            InitializeComponent();
            _check = new CheckPost();
 

        }

        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
