﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logic.Vehicle
{
    public class LicensePlate : AProperties
    {


        public LicensePlate(string regnr, string vehicleType)
        {
            this.Registration_Nr = regnr;
            this.Vehicle_Type = Vehicle_Type;                
        }
    }
}
