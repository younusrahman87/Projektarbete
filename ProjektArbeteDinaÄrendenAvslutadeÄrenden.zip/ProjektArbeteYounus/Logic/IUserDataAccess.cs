﻿using System;
using System.Collections.Generic;
using System.Text;
using Logic.DAL;
using Logic.Entities;
using Logic;
using Logic.Services;
using Logic.Vehicle;

namespace Logic
{
    public interface IUserDataAccess
    {


        public enum File_Type { Users = 1, Mekanik, Komponent, Motorcykel, Bil, Lastbil, Buss, Order, LicensePlate };
        public enum Components { Bromsar = 1, Motor, Kaross, Vindruta, Däck }
        public enum TypeOfUser { Admin = 1, Mekanik }
        public enum VStatus { Pending, Work_In_Progress, Done }
        public static object Current_user { get; set; }


        public static Dictionary<T, J> Read<T, J>(string file_type)
        {
            return UserDataAccess.Read<T, J>(file_type);
        }

        public static void Write<T, J>(Dictionary<T, J> dict, string file_type)
        {
            UserDataAccess.Write<T, J>(dict, file_type);
        }


        public static (bool, LoginService) LoginCheck(string Username, string Password)
        {
            LoginService _loginService = new LoginService();

            return _loginService.Login(Username, Password) ? (true, _loginService) : (false, null);
        }

        public static object GetVehicleInfo( string rgnr, string vehicle_typ)
        {
            if (vehicle_typ == Enum.GetName(typeof(IUserDataAccess.File_Type), 4))
            {return IUserDataAccess.Read<string, Motorcycle>(Enum.GetName(typeof(IUserDataAccess.File_Type), 4))[rgnr]; }
            else if (vehicle_typ == Enum.GetName(typeof(IUserDataAccess.File_Type), 5))
            { return IUserDataAccess.Read<string, Car>(Enum.GetName(typeof(IUserDataAccess.File_Type), 5))[rgnr]; }
            else if (vehicle_typ == Enum.GetName(typeof(IUserDataAccess.File_Type), 6))
            { return IUserDataAccess.Read<string, Truck>(Enum.GetName(typeof(IUserDataAccess.File_Type), 6))[rgnr]; }
            else 
            { return IUserDataAccess.Read<string, Bus>(Enum.GetName(typeof(IUserDataAccess.File_Type), 7))[rgnr]; }



        }

    }
}
