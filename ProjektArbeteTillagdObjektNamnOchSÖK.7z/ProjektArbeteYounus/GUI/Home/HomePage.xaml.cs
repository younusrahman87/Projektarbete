﻿using GUI.Login;
using GUI.Pages;
using Logic;
using Logic.Entities;
using Logic.Services;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GUI.Home
{
    /// <summary>
    /// Interaction logic for HomePage.xaml
    /// </summary>
    public partial class HomePage : Page
    {
        private string searchboxtxt = "Ange ärendenummer";
        private static object[] Current_user;
        public static object[] _GCU { get { if (Current_user == null) { Current_user = new object[4]; } return Current_user;} }
        public HomePage()
        {
            InitializeComponent();                        
            Sing_out_bt.Content = $"Loga ut [{ _GCU[0].ToString() }]";
        }

        private void Sing_out_BT_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new LoginPage());
        }


        private void Search_box_got_focuse(object sender, RoutedEventArgs e)
        {
            if (Search_box.Text.Equals(searchboxtxt))
            { Search_box.Text = string.Empty; }


        }

        private void Search_box_lost_focuse(object sender, RoutedEventArgs e)
        {
            if (Search_box.Text.Equals(string.Empty))
            { Search_box.Text = searchboxtxt; }
        }

        private void Sing_out_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new LoginPage());
        }

        private void Search_BT_Click(object sender, RoutedEventArgs e)
        {
            if (!Search_box.Text.Equals(searchboxtxt))
            { 
                
                if (IUserDataAccess.Read<string, VehicleCase>(Enum.GetName(typeof(IUserDataAccess.File_Type),8)).ContainsKey(Search_box.Text))
                {
                SearchWindow serarch_obj = new SearchWindow();
                //var mainwin = Application.Current.MainWindow;

                //mainwin.Hide();


                serarch_obj.ShowDialog();
                }
                else { MessageBox.Show("**Du angav fel ärendenummer **", "::. Söka ärande .:: ", MessageBoxButton.OK,MessageBoxImage.Warning) ; }


            }

            Search_box.Text = searchboxtxt;

        }

        private void add_vehicle_Click(object sender, RoutedEventArgs e)
        {
            Menubar_frame.Navigate(new Add_vehicle());
        }

        private void Add_case_Click(object sender, RoutedEventArgs e)
        {
            Menubar_frame.Navigate(new Case());
        }

        private void Profil_Click_Click(object sender, RoutedEventArgs e)
        {
            Menubar_frame.Navigate(new Case());
        }

        private void Assignments_bt_Click(object sender, RoutedEventArgs e)
        {
            Menubar_frame.Navigate(new DinaUppdrag());
        }
    }
}
