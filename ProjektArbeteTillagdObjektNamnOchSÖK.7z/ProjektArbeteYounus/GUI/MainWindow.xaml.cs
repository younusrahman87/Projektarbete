﻿using Logic;
using Logic.Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : NavigationWindow, IUserDataAccess
    {

        public MainWindow()
        {

            ShowsNavigationUI = false;
            InitializeComponent();
        }

        static MainWindow()
        {
            
            string path = $"DAL\\Users.json";
            if (!File.Exists(path))
            {
                Directory.CreateDirectory("DAL\\");
                Dictionary<string, User> Default_dict = new Dictionary<string, User>();
                var Bosse = new User(Enum.GetName(typeof(IUserDataAccess.TypeOfUser), 1), "Bosse", "Meckarn123", "12345");
                Default_dict.Add("Bosse", Bosse);

                IUserDataAccess.Write<string, User>(Default_dict, "Users");
               
            }           

        }

    }
}
