﻿using System;
using System.Collections.Generic;
using System.Text;
using Logic.Vehicle;

namespace Logic.Entities
{
    public class Mechanic
    {
        public DateTime Birthdate { get; set; }
        public string MechanicId { get; set; }
        public string Namn { get; set; }
        public string Skills { get; set; }
        public static AProperties[] Work_Status = new AProperties[1];



        public Mechanic(string namn, string birth, string skills)
        {
            Birthdate = Convert.ToDateTime(birth);
            MechanicId = Guid.NewGuid().ToString();
            Namn = namn;
            Skills = skills;
        }




    }
}
