﻿using Logic.Vehicle;
using System;
using System.Collections.Generic;
using System.Text;

namespace Logic
{
    public class VehicleCase
    {
        public string CaseID { get; set; }
        public string Comments { get; set; }
        public string Vehicle_Type { get; set; }
        public string Vehicle_Issue { get; set; }
        public int Mechanic_ID { get; set; }
        public string Vehicle_Status { get; set; }



        public VehicleCase(string caseid, string vehicle_Type, string vehicle_Issue, int mechanic_ID, string vehicle_Status, string comments = "**Ingen kommentar**")
        {
            this.CaseID = caseid;
            this.Vehicle_Type = vehicle_Type;
            this.Vehicle_Issue = vehicle_Issue;
            this.Mechanic_ID = mechanic_ID;
            this.Vehicle_Status = vehicle_Status;
            this.Comments = comments;

        }



    }
}
